import json
import boto3
import base64
import os
from datetime import datetime
from typing import Dict, Any, List
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
bedrock_client = boto3.client('bedrock-runtime', region_name=os.environ.get('AWS_REGION', 'us-east-1'))
s3_client = boto3.client('s3', region_name=os.environ.get('AWS_REGION', 'us-east-1'))
dynamodb = boto3.resource('dynamodb', region_name=os.environ.get('AWS_REGION', 'us-east-1'))

# Environment variables
BUCKET_NAME = os.environ.get('BUCKET_NAME', 'cognia-intellilearn')
DYNAMODB_TABLE = os.environ.get('DYNAMODB_TABLE', 'intellilearn_Data')

def lambda_handler(event: Dict[str, Any], context) -> Dict[str, Any]:
    """
    Enhanced AWS Lambda handler for Bedrock voice streaming with AI Content architecture
    """
    try:
        # Handle CORS preflight
        if event.get('httpMethod') == 'OPTIONS':
            return handle_options()
            
        # Parse request body
        if 'body' in event:
            body = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
        else:
            body = event
            
        # Extract enhanced payload
        audio_data = body.get('audioData', '')
        session_id = body.get('sessionId', 'unknown')
        course_id = body.get('courseId', '000000000')
        topic = body.get('topic', 'General')
        student_id = body.get('studentId', 'student_default')
        context_sources = body.get('contextSources', [])
        action = body.get('action', 'stream_audio')
        
        logger.info(f"🎯 Processing enhanced voice session: {session_id}")
        logger.info(f"📚 Course: {course_id}, Topic: {topic}, Student: {student_id}")
        logger.info(f"🔍 Context sources: {len(context_sources)}")
        
        # Handle different actions
        if action == 'stop_session':
            return handle_session_stop(session_id)
            
        # Get educational context
        educational_context = get_educational_context(context_sources, course_id, topic)
        
        # Create enhanced prompt with educational context
        enhanced_prompt = create_educational_prompt(audio_data, topic, educational_context)
        
        # Prepare Bedrock streaming request
        bedrock_request = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1000,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": enhanced_prompt
                        }
                    ]
                }
            ],
            "stream": True,
            "temperature": 0.7,
            "top_p": 0.9
        }
        
        # Invoke Bedrock with streaming
        response = bedrock_client.invoke_model_with_response_stream(
            modelId='anthropic.claude-3-haiku-20240307-v1:0',
            contentType='application/json',
            accept='application/json',
            body=json.dumps(bedrock_request)
        )
        
        # Process streaming response with AI Content integration
        full_response = ""
        streaming_chunks = []
        
        for event_stream in response['body']:
            chunk = event_stream.get('chunk')
            if chunk:
                chunk_data = json.loads(chunk['bytes'].decode())
                
                if chunk_data['type'] == 'content_block_delta':
                    text_chunk = chunk_data['delta'].get('text', '')
                    if text_chunk:
                        full_response += text_chunk
                        
                        # Create streaming chunk for frontend
                        chunk_response = {
                            'type': 'ai_response',
                            'text': text_chunk,
                            'sessionId': session_id,
                            'timestamp': datetime.now().isoformat()
                        }
                        streaming_chunks.append(chunk_response)
                        
                        logger.info(f"📝 AI Chunk: {text_chunk[:50]}...")
        
        # Save AI Content to S3 and DynamoDB
        save_ai_content(session_id, course_id, topic, student_id, enhanced_prompt, full_response)
        
        # Create final response chunks
        final_chunks = [
            {
                'type': 'transcription',
                'text': f"Audio procesado para sesión de {topic}",
                'sessionId': session_id
            }
        ] + streaming_chunks + [
            {
                'type': 'stream_end',
                'sessionId': session_id,
                'fullResponse': full_response,
                'metadata': {
                    'courseId': course_id,
                    'topic': topic,
                    'studentId': student_id,
                    'contextSourcesUsed': len(context_sources)
                }
            }
        ]
        
        logger.info(f"✅ Enhanced streaming completed for session: {session_id}")
        
        # Return streaming response
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            'body': json.dumps({
                'success': True,
                'sessionId': session_id,
                'chunks': final_chunks,
                'fullResponse': full_response,
                'aiContentSaved': True,
                'metadata': {
                    'model': 'claude-3-haiku',
                    'courseId': course_id,
                    'topic': topic,
                    'chunksCount': len(streaming_chunks),
                    'responseLength': len(full_response),
                    'contextSources': len(context_sources)
                }
            })
        }
        
    except Exception as e:
        logger.error(f"❌ Enhanced Lambda error: {str(e)}")
        
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'success': False,
                'error': 'Error procesando solicitud de voz educativa',
                'details': str(e),
                'sessionId': session_id if 'session_id' in locals() else 'unknown'
            })
        }

def get_educational_context(context_sources: List[str], course_id: str, topic: str) -> str:
    """
    Retrieve educational context from S3 sources
    """
    try:
        context_content = []
        
        # Limit to first 3 sources for performance
        for source_path in context_sources[:3]:
            try:
                response = s3_client.get_object(Bucket=BUCKET_NAME, Key=source_path)
                content = response['Body'].read().decode('utf-8')
                
                # Truncate content to avoid token limits
                truncated_content = content[:500] if len(content) > 500 else content
                context_content.append(f"📄 {source_path.split('/')[-1]}: {truncated_content}")
                
            except Exception as e:
                logger.warning(f"⚠️ Could not retrieve context from {source_path}: {e}")
                continue
        
        if context_content:
            return "\n".join(context_content)
        else:
            return f"Contenido educativo relacionado con {topic} en el curso {course_id}"
            
    except Exception as e:
        logger.error(f"❌ Error getting educational context: {e}")
        return f"Contexto educativo general para {topic}"

def create_educational_prompt(audio_data: str, topic: str, context: str) -> str:
    """
    Create enhanced educational prompt with context
    """
    return f"""Eres CognIA, un asistente educativo inteligente especializado en aprendizaje interactivo y personalizado.

🎯 CONTEXTO EDUCATIVO:
Tema principal: {topic}
Contenido de referencia disponible:
{context}

🎤 SESIÓN DE VOZ:
El estudiante está en una sesión de voz interactiva. Audio procesado: {len(audio_data)} caracteres de datos de audio.

📚 INSTRUCCIONES:
1. Responde como un profesor experto en {topic}
2. Usa el contenido de referencia cuando sea relevante
3. Mantén respuestas conversacionales y pedagógicas (máximo 3 oraciones)
4. Haz preguntas para mantener el engagement
5. Adapta el nivel según las respuestas del estudiante
6. Usa un tono amigable y profesional

🚀 INICIO:
Saluda al estudiante y pregunta específicamente qué aspecto de {topic} quiere explorar o en qué puedes ayudarle. Menciona que tienes acceso a material educativo especializado."""

def save_ai_content(session_id: str, course_id: str, topic: str, student_id: str, prompt: str, response: str):
    """
    Save AI content to S3 and metadata to DynamoDB following AIContent structure
    """
    try:
        timestamp = datetime.now().isoformat()
        date_prefix = datetime.now().strftime('%Y-%m-%d')
        
        # Save Bedrock prompt to S3
        prompt_key = f"AIContent/BedrockPrompts/{topic}/{session_id}.json"
        prompt_data = {
            'sessionId': session_id,
            'courseId': course_id,
            'topic': topic,
            'studentId': student_id,
            'prompt': prompt,
            'response': response,
            'timestamp': timestamp,
            'model': 'anthropic.claude-3-haiku-20240307-v1:0'
        }
        
        s3_client.put_object(
            Bucket=BUCKET_NAME,
            Key=prompt_key,
            Body=json.dumps(prompt_data, indent=2),
            ContentType='application/json',
            Metadata={
                'sessionId': session_id,
                'courseId': course_id,
                'topic': topic,
                'studentId': student_id
            }
        )
        
        # Save text output to S3
        text_key = f"AIContent/TextOutput/{student_id}/{session_id}.txt"
        s3_client.put_object(
            Bucket=BUCKET_NAME,
            Key=text_key,
            Body=response,
            ContentType='text/plain',
            Metadata={
                'sessionId': session_id,
                'studentId': student_id,
                'createdAt': timestamp
            }
        )
        
        # Save metadata to DynamoDB
        table = dynamodb.Table(DYNAMODB_TABLE)
        table.put_item(
            Item={
                'PK': f'VOICE_SESSION#{session_id}',
                'SK': 'METADATA',
                'sessionId': session_id,
                'courseId': course_id,
                'topic': topic,
                'studentId': student_id,
                'promptKey': prompt_key,
                'textKey': text_key,
                'responseLength': len(response),
                'createdAt': timestamp,
                'TTL': int(datetime.now().timestamp()) + (30 * 24 * 60 * 60)  # 30 days
            }
        )
        
        logger.info(f"💾 AI Content saved: {prompt_key}, {text_key}")
        
    except Exception as e:
        logger.error(f"❌ Error saving AI content: {e}")

def handle_session_stop(session_id: str) -> Dict[str, Any]:
    """
    Handle session stop cleanup
    """
    logger.info(f"🛑 Stopping session: {session_id}")
    
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({
            'success': True,
            'message': f'Session {session_id} stopped',
            'sessionId': session_id
        })
    }

def handle_options():
    """Handle CORS preflight requests"""
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization',
            'Access-Control-Allow-Methods': 'POST, OPTIONS'
        },
        'body': ''
    }

# Export for Lambda deployment
__all__ = ['lambda_handler'] 