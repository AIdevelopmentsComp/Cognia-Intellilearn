/**
 * AWS Lambda WebSocket Handler for Nova Sonic
 * Handles WebSocket connections, messages, and Nova Sonic communication
 * 
 * Architecture: API Gateway WebSocket → Lambda → Nova Sonic (Bedrock)
 */

const { 
  BedrockRuntimeClient,
  InvokeModelWithBidirectionalStreamCommand 
} = require('@aws-sdk/client-bedrock-runtime');
const { 
  ApiGatewayManagementApiClient,
  PostToConnectionCommand 
} = require('@aws-sdk/client-apigatewaymanagementapi');
const { 
  DynamoDBClient,
  PutItemCommand,
  GetItemCommand,
  DeleteItemCommand,
  UpdateItemCommand 
} = require('@aws-sdk/client-dynamodb');
const { fromCognitoIdentityPool } = require('@aws-sdk/credential-providers');

// Configuration
const AWS_REGION = process.env.AWS_REGION || 'us-east-1';
const NOVA_SONIC_MODEL_ID = process.env.NOVA_SONIC_MODEL_ID || 'amazon.nova-sonic-v1:0';
const CONNECTIONS_TABLE = process.env.CONNECTIONS_TABLE || 'NovaWebSocketConnections';
const SESSIONS_TABLE = process.env.SESSIONS_TABLE || 'NovaWebSocketSessions';
const COGNITO_IDENTITY_POOL_ID = process.env.COGNITO_IDENTITY_POOL_ID;
const COGNITO_USER_POOL_ID = process.env.COGNITO_USER_POOL_ID;

// AWS Clients
const dynamoClient = new DynamoDBClient({ region: AWS_REGION });
const bedrockClient = new BedrockRuntimeClient({ region: AWS_REGION });

/**
 * Main Lambda handler
 */
exports.handler = async (event) => {
  console.log('📨 Received WebSocket event:', JSON.stringify(event, null, 2));
  
  const { requestContext } = event;
  const { routeKey, connectionId, domainName, stage } = requestContext;
  
  // Create API Gateway Management API client for this connection
  const apiGwClient = new ApiGatewayManagementApiClient({
    region: AWS_REGION,
    endpoint: `https://${domainName}/${stage}`
  });

  try {
    switch (routeKey) {
      case '$connect':
        return await handleConnect(connectionId, event);
        
      case '$disconnect':
        return await handleDisconnect(connectionId);
        
      case '$default':
      case 'message':
        return await handleMessage(connectionId, event, apiGwClient);
        
      default:
        console.warn(`⚠️ Unknown route: ${routeKey}`);
        return { statusCode: 400, body: 'Unknown route' };
    }
  } catch (error) {
    console.error('❌ Lambda handler error:', error);
    
    // Try to send error to client
    try {
      await sendToConnection(apiGwClient, connectionId, {
        type: 'error',
        error: error.message,
        timestamp: new Date().toISOString()
      });
    } catch (sendError) {
      console.error('❌ Failed to send error to client:', sendError);
    }
    
    return { statusCode: 500, body: 'Internal server error' };
  }
};

/**
 * Handle WebSocket connection
 */
async function handleConnect(connectionId, event) {
  console.log(`🔌 New WebSocket connection: ${connectionId}`);
  
  try {
    // Store connection in DynamoDB
    await dynamoClient.send(new PutItemCommand({
      TableName: CONNECTIONS_TABLE,
      Item: {
        connectionId: { S: connectionId },
        connectedAt: { S: new Date().toISOString() },
        ttl: { N: Math.floor(Date.now() / 1000 + 3600).toString() } // 1 hour TTL
      }
    }));
    
    console.log(`✅ Connection ${connectionId} stored in DynamoDB`);
    
    return { statusCode: 200, body: 'Connected' };
    
  } catch (error) {
    console.error('❌ Error handling connect:', error);
    return { statusCode: 500, body: 'Failed to connect' };
  }
}

/**
 * Handle WebSocket disconnection
 */
async function handleDisconnect(connectionId) {
  console.log(`🔌 WebSocket disconnection: ${connectionId}`);
  
  try {
    // Remove connection from DynamoDB
    await dynamoClient.send(new DeleteItemCommand({
      TableName: CONNECTIONS_TABLE,
      Key: {
        connectionId: { S: connectionId }
      }
    }));
    
    // Clean up any active sessions for this connection
    await cleanupSessions(connectionId);
    
    console.log(`✅ Connection ${connectionId} cleaned up`);
    
    return { statusCode: 200, body: 'Disconnected' };
    
  } catch (error) {
    console.error('❌ Error handling disconnect:', error);
    return { statusCode: 500, body: 'Failed to disconnect' };
  }
}

/**
 * Handle WebSocket messages
 */
async function handleMessage(connectionId, event, apiGwClient) {
  console.log(`📨 Message from connection ${connectionId}`);
  
  try {
    const message = JSON.parse(event.body);
    console.log('📋 Message type:', message.type);
    
    switch (message.type) {
      case 'initialize_session':
        return await handleInitializeSession(connectionId, message, apiGwClient);
        
      case 'audio_input':
        return await handleAudioInput(connectionId, message, apiGwClient);
        
      case 'end_session':
        return await handleEndSession(connectionId, message, apiGwClient);
        
      case 'ping':
        await sendToConnection(apiGwClient, connectionId, {
          type: 'pong',
          timestamp: new Date().toISOString()
        });
        return { statusCode: 200, body: 'Pong sent' };
        
      default:
        console.warn(`⚠️ Unknown message type: ${message.type}`);
        await sendToConnection(apiGwClient, connectionId, {
          type: 'error',
          error: `Unknown message type: ${message.type}`
        });
        return { statusCode: 400, body: 'Unknown message type' };
    }
    
  } catch (parseError) {
    console.error('❌ Error parsing message:', parseError);
    
    await sendToConnection(apiGwClient, connectionId, {
      type: 'error',
      error: 'Invalid message format'
    });
    
    return { statusCode: 400, body: 'Invalid message format' };
  }
}

/**
 * Initialize Nova Sonic session
 */
async function handleInitializeSession(connectionId, message, apiGwClient) {
  console.log(`🎯 Initializing Nova Sonic session for connection: ${connectionId}`);
  
  try {
    const { authToken, courseId, studentId } = message;
    
    if (!authToken) {
      throw new Error('Auth token required');
    }
    
    // Generate session ID
    const sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    // Create Bedrock client with Cognito credentials
    const bedrockClientWithCognito = new BedrockRuntimeClient({
      region: AWS_REGION,
      credentials: fromCognitoIdentityPool({
        identityPoolId: COGNITO_IDENTITY_POOL_ID,
        logins: {
          [`cognito-idp.${AWS_REGION}.amazonaws.com/${COGNITO_USER_POOL_ID}`]: authToken
        }
      })
    });
    
    // Store session in DynamoDB
    await dynamoClient.send(new PutItemCommand({
      TableName: SESSIONS_TABLE,
      Item: {
        sessionId: { S: sessionId },
        connectionId: { S: connectionId },
        courseId: { S: courseId || 'default' },
        studentId: { S: studentId || 'default' },
        isActive: { BOOL: true },
        createdAt: { S: new Date().toISOString() },
        ttl: { N: Math.floor(Date.now() / 1000 + 3600).toString() } // 1 hour TTL
      }
    }));
    
    console.log(`✅ Session ${sessionId} created and stored`);
    
    // Initialize Nova Sonic stream (simplified for Lambda)
    // In production, you might want to use step functions or separate Lambda
    await sendToConnection(apiGwClient, connectionId, {
      type: 'session_initialized',
      sessionId,
      message: 'Nova Sonic session ready for audio input'
    });
    
    // Send session ready notification
    await sendToConnection(apiGwClient, connectionId, {
      type: 'nova_session_ready',
      sessionId,
      message: 'Nova Sonic session initialized successfully'
    });
    
    return { statusCode: 200, body: 'Session initialized' };
    
  } catch (error) {
    console.error('❌ Error initializing session:', error);
    
    await sendToConnection(apiGwClient, connectionId, {
      type: 'error',
      error: `Session initialization failed: ${error.message}`
    });
    
    return { statusCode: 500, body: 'Session initialization failed' };
  }
}

/**
 * Handle audio input from client
 */
async function handleAudioInput(connectionId, message, apiGwClient) {
  console.log(`🎤 Audio input from connection: ${connectionId}`);
  
  try {
    const { sessionId, audioData } = message;
    
    if (!sessionId || !audioData) {
      throw new Error('Session ID and audio data required');
    }
    
    // Get session from DynamoDB
    const sessionResult = await dynamoClient.send(new GetItemCommand({
      TableName: SESSIONS_TABLE,
      Key: {
        sessionId: { S: sessionId }
      }
    }));
    
    if (!sessionResult.Item) {
      throw new Error('Session not found');
    }
    
    const session = sessionResult.Item;
    if (session.connectionId.S !== connectionId) {
      throw new Error('Session does not belong to this connection');
    }
    
    console.log(`🎤 Processing audio for session: ${sessionId}`);
    
    // Create Nova Sonic bidirectional stream command
    // Note: In a real implementation, you'd want to handle the stream properly
    // This is a simplified version for demonstration
    const eventGenerator = createAudioEventGenerator(audioData, session);
    
    const command = new InvokeModelWithBidirectionalStreamCommand({
      modelId: NOVA_SONIC_MODEL_ID,
      body: eventGenerator
    });
    
    console.log(`📡 Invoking Nova Sonic for session: ${sessionId}`);
    
    // Execute command and process response
    const response = await bedrockClient.send(command);
    
    if (response.body) {
      // Process Nova Sonic response stream
      await processNovaResponse(response.body, connectionId, sessionId, apiGwClient);
    }
    
    return { statusCode: 200, body: 'Audio processed' };
    
  } catch (error) {
    console.error('❌ Error processing audio input:', error);
    
    await sendToConnection(apiGwClient, connectionId, {
      type: 'error',
      error: `Audio processing failed: ${error.message}`
    });
    
    return { statusCode: 500, body: 'Audio processing failed' };
  }
}

/**
 * Create event generator for Nova Sonic
 */
async function* createAudioEventGenerator(audioData, session) {
  // Session start
  yield {
    chunk: {
      bytes: new TextEncoder().encode(JSON.stringify({
        event: {
          sessionStart: {
            inferenceConfiguration: {
              maxTokens: 1024,
              topP: 0.9,
              temperature: 0.7
            }
          }
        }
      }))
    }
  };
  
  // Prompt start
  yield {
    chunk: {
      bytes: new TextEncoder().encode(JSON.stringify({
        event: {
          promptStart: {
            promptName: `session_${session.sessionId.S}`,
            additionalModelRequestFields: {}
          }
        }
      }))
    }
  };
  
  // Content start
  yield {
    chunk: {
      bytes: new TextEncoder().encode(JSON.stringify({
        event: {
          contentStart: {
            promptName: `session_${session.sessionId.S}`,
            contentName: `audio_${session.sessionId.S}`
          }
        }
      }))
    }
  };
  
  // Audio input
  yield {
    chunk: {
      bytes: new TextEncoder().encode(JSON.stringify({
        event: {
          audioInput: {
            promptName: `session_${session.sessionId.S}`,
            contentName: `audio_${session.sessionId.S}`,
            content: audioData.base64 || audioData
          }
        }
      }))
    }
  };
  
  // Audio input end
  yield {
    chunk: {
      bytes: new TextEncoder().encode(JSON.stringify({
        event: {
          audioInputEnd: {}
        }
      }))
    }
  };
}

/**
 * Process Nova Sonic response stream
 */
async function processNovaResponse(stream, connectionId, sessionId, apiGwClient) {
  try {
    console.log(`📥 Processing Nova response stream for session: ${sessionId}`);
    
    let eventCount = 0;
    
    for await (const chunk of stream) {
      eventCount++;
      
      if (chunk.chunk && chunk.chunk.bytes) {
        const eventData = new TextDecoder().decode(chunk.chunk.bytes);
        const parsedEvent = JSON.parse(eventData);
        
        const eventType = Object.keys(parsedEvent.event || {})[0];
        console.log(`📨 Nova event ${eventCount} (${sessionId}):`, eventType);
        
        // Forward to client
        await sendToConnection(apiGwClient, connectionId, {
          type: 'nova_response',
          sessionId,
          event: parsedEvent.event,
          eventCount
        });
      }
    }
    
    console.log(`✅ Nova response processing completed. Total events: ${eventCount}`);
    
  } catch (error) {
    console.error('❌ Error processing Nova response:', error);
    
    await sendToConnection(apiGwClient, connectionId, {
      type: 'nova_error',
      sessionId,
      error: error.message
    });
  }
}

/**
 * Handle session end
 */
async function handleEndSession(connectionId, message, apiGwClient) {
  console.log(`🛑 Ending session for connection: ${connectionId}`);
  
  try {
    const { sessionId } = message;
    
    if (sessionId) {
      // Mark session as inactive
      await dynamoClient.send(new UpdateItemCommand({
        TableName: SESSIONS_TABLE,
        Key: {
          sessionId: { S: sessionId }
        },
        UpdateExpression: 'SET isActive = :inactive',
        ExpressionAttributeValues: {
          ':inactive': { BOOL: false }
        }
      }));
      
      console.log(`✅ Session ${sessionId} marked as inactive`);
    }
    
    await sendToConnection(apiGwClient, connectionId, {
      type: 'session_ended',
      sessionId,
      message: 'Session ended successfully'
    });
    
    return { statusCode: 200, body: 'Session ended' };
    
  } catch (error) {
    console.error('❌ Error ending session:', error);
    return { statusCode: 500, body: 'Failed to end session' };
  }
}

/**
 * Send message to WebSocket connection
 */
async function sendToConnection(apiGwClient, connectionId, message) {
  try {
    await apiGwClient.send(new PostToConnectionCommand({
      ConnectionId: connectionId,
      Data: JSON.stringify(message)
    }));
    
    console.log(`📤 Message sent to connection ${connectionId}:`, message.type);
    
  } catch (error) {
    if (error.statusCode === 410) {
      console.log(`🔌 Connection ${connectionId} is stale, removing...`);
      await cleanupConnection(connectionId);
    } else {
      console.error(`❌ Failed to send message to ${connectionId}:`, error);
      throw error;
    }
  }
}

/**
 * Cleanup stale connection
 */
async function cleanupConnection(connectionId) {
  try {
    await dynamoClient.send(new DeleteItemCommand({
      TableName: CONNECTIONS_TABLE,
      Key: {
        connectionId: { S: connectionId }
      }
    }));
    
    await cleanupSessions(connectionId);
    
  } catch (error) {
    console.error(`❌ Error cleaning up connection ${connectionId}:`, error);
  }
}

/**
 * Cleanup sessions for connection
 */
async function cleanupSessions(connectionId) {
  try {
    // In a real implementation, you'd scan for sessions with this connectionId
    // and clean them up. For now, we'll skip this for brevity.
    console.log(`🧹 Cleaning up sessions for connection: ${connectionId}`);
    
  } catch (error) {
    console.error(`❌ Error cleaning up sessions for ${connectionId}:`, error);
  }
}